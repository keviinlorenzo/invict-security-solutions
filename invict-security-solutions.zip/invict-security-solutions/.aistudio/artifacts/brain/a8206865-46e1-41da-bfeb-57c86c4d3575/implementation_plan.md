# Plan de Implementación: Seguridad Integral, Asistente BONO, Comparativa de Carga y Soporte PWA - INVICT Security Solutions S.A.

Implementación de mejoras críticas de seguridad, chatbot de IA flotante "BONO", informe comparativo de carga por colaborador, restricción estricta de puestos y habilitación de instalación nativa PWA para INVICT Security Solutions S.A.

## User Review & Critical Decisions

> [!IMPORTANT]
> Se han incorporado las directivas clave del usuario: eliminación total de claves maestras/universales, despacho directo a Gmail/Outlook para recuperación de credenciales de Gerencia, bloqueo de cambio de puesto para personal regular, chatbot flotante BONO con IA Gemini 3.8, comparativa de cuellos de botella por colaborador individual, logotipos oficiales subidos e instalación de escritorio (PWA).

- **Confirmed Decision 1**: Despacho de recuperación de contraseña a Gerencia (`consultasinvictsolutionss.a@gmail.com`) mediante conector directo con token cifrado y enlaces directos de apertura para Gmail y Outlook web, más llamada segura al backend.
- **Confirmed Decision 2**: Eliminación total de la clave universal (`INVICT2026` / `Gerencia2026!`). Cada puesto cuenta con su contraseña individual y exclusiva.
- **Confirmed Decision 3**: Restricción estricta de cambio de puesto: cuando un colaborador ingresa con su cuenta (Operaciones, RRHH, Administración, etc.), se oculta y bloquea el selector de perfiles. Solo Gerencia General conserva la facultad de cambiar y alternar entre puestos.
- **Confirmed Decision 4**: Chatbot flotante "BONO" (amigo y asistente de los puestos) en la esquina inferior derecha con IA de Gemini (`gemini-3.8-flash` en `/api/bono-chat`), brindando soporte sobre uso de la app, recordatorios de vencimientos, recomendaciones operativas e investigaciones.
- **Confirmed Decision 5**: Comparativa de carga de trabajo en el informe ejecutivo por colaborador individual (Kevin, Pilar, Giuliana, Valeria, Mariana, Yamila) con gráfico comparativo de barras (Tareas Totales vs. Completadas) para identificar cuellos de botella.
- **Confirmed Decision 6**: Integración de los logotipos reales proporcionados (`WhatsApp Image 2026-04-28 at 09.16.07.jpeg` y `WhatsApp Image 2026-04-28 at 09.19.11.jpeg`) y habilitación de instalación PWA en escritorio (`manifest.json`, `sw.js`, guía de instalación).

---

## 1. Overview & Core Concept

- **What It Does**: Fortalece la seguridad y usabilidad del sistema de INVICT Security Solutions S.A. garantizando autenticación individualizada, asistencia inteligente en tiempo real con BONO, análisis visual de sobrecarga laboral y capacidad de operar como aplicación nativa de escritorio en las computadoras de Base Central Maipú y puestos de vigilancia.
- **Target Audience / Persona**:
  - **Dirección General**: Supervisión de cuellos de botella, recepción de alertas de seguridad en `consultasinvictsolutionss.a@gmail.com`, acceso irrestricto a todos los puestos.
  - **Puestos de Vigilancia y Mandos Medios**: Asistencia paso a paso con BONO, acceso restringido a su propia área, observaciones con `@` y acceso rápido desde el escritorio de Windows/Edge/Chrome.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. *Recuperación Segura de Contraseña*: Al solicitar recuperación de Gerencia, se emite un token criptográfico y se abre automáticamente el conector hacia Gmail / Outlook Web preconfigurado para `consultasinvictsolutionss.a@gmail.com`.
  2. *Control de Puesto Restringido*: Los colaboradores no ven el selector de perfiles en el encabezado ni en la barra lateral; solo pueden ver y operar su propio puesto asignado.
  3. *Interacción con BONO*: Botón flotante carmín en la esquina inferior derecha con indicador de estado; al abrirse despliega una ventana moderna de chat con sugerencias rápidas, alertas de tareas urgentes y respuestas de IA contextualizadas.
  4. *Observaciones con `@`*: En el modal de detalle de cada tarea, los usuarios pueden redactar notas etiquetando a `@Gerencia`, `@Kevin`, etc., despachando alertas automáticas.
  5. *Gráfico Comparativo de Cuellos de Botella*: En el Módulo de Informes Ejecutivos, una nueva sección muestra un gráfico comparativo de barras (`Tareas Totales` vs. `Completadas`) agrupado por colaborador individual con badge de estado.
  6. *Instalación PWA en PC*: Botón en el encabezado para instalación en un solo clic y modal explicativo detallado para fijar la app en la barra de tareas de Windows y escritorio.
- **Visual Identity**:
  - Uso estricto de los logotipos reales subidos en el encabezado, pantalla de inicio, pie de página e informes.
  - Paleta ejecutiva oscura `#07090e`, acento carmín `#BE2629`, tipografía `Plus Jakarta Sans` y cifras monoespaciadas `JetBrains Mono`.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Eliminación definitiva de Backdoors y Claves Maestras**
  - *Approach*: Eliminar `INVICT2026` y accesos automáticos de rescate en `verifyProfilePassword`. Cada usuario debe validar su clave activa individual gestionada por Gerencia.
  - *Why*: Cumplimiento con la directiva explícita de seguridad del cliente.
- **Decision 2: Conector Directo Gmail / Outlook Web con Token de Recuperación**
  - *Approach*: Generación de token firmado temporal almacenado en el sistema y creación de enlaces con protocolo `mailto:` / `https://mail.google.com/mail/?view=cm` y `https://outlook.live.com` con asunto y cuerpo corporativo pre-cargado.
  - *Why*: Evita bloqueos de SMTP de terceros en navegadores estáticos y garantiza que el correo llegue de forma fidedigna a la casilla de Gerencia.
- **Decision 3: Backend Express con Vite Middleware para IA Segura de BONO**
  - *Approach*: Servidor `server.ts` con endpoint `/api/bono-chat` utilizando `@google/genai` con modelo `gemini-3.8-flash` y fallback inteligente ante interrupciones de red.
  - *Why*: Protege la API key de Gemini en el lado del servidor y ofrece respuestas rápidas y enriquecidas sobre la plataforma y normativas de seguridad privada.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                   INVICT Security Solutions S.A.                        │
│                   Plataforma Ejecutiva & Operativa                      │
└────────────────────────────────────┬───────────────────────────────────┘
                                     │
           ┌─────────────────────────┼────────────────────────┐
           ▼                         ▼                        ▼
┌───────────────────────┐ ┌────────────────────┐ ┌────────────────────────┐
│  Seguridad & Accesos  │ │  Asistente BONO    │ │  Informes Ejecutivos   │
│  - Sin clave universal│ │  - Botón flotante  │ │  - Barras por persona  │
│  - Conector Gmail     │ │  - Gemini 3.8 API  │ │  - Detección de mora   │
│  - Bloqueo no-gerentes│ │  - Tareas urgentes │ │  - Exportación PDF/CSV │
└──────────┬────────────┘ └──────────┬─────────┘ └───────────┬────────────┘
           │                         │                       │
           └─────────────────────────┼───────────────────────┘
                                     ▼
┌────────────────────────────────────────────────────────────────────────┐
│                  PWA & Soporte de Escritorio (PC)                      │
│   - public/manifest.json (display: standalone, theme: #BE2629)         │
│   - public/sw.js (caching & background notifications)                  │
│   - usePWAInstall hook + PWAInstallGuideModal (Chrome / Edge)          │
│   - Logotipos reales integrados (WhatsApp Images en public/assets)     │
└────────────────────────────────────────────────────────────────────────┘
```

- **Entities & Data**:
  - `Task`: Soporte de menciones `@`, turno, objetivo y colaborador asignado.
  - `UserPersona`: Indicador de permisos para conmutación de puestos (restringido a `GERENTE`).
  - `WorkloadMetric`: Métrica comparativa por colaborador (`name`, `role`, `totalTasks`, `completedTasks`, `pendingTasks`, `overdueTasks`, `bottleneckRisk`).
- **Files to create/modify**:
  - `server.ts`: Configurar servidor Express con `/api/bono-chat` y `/api/notify-gerencia-recovery`.
  - `package.json`: Ajustar `"dev": "tsx server.ts"` para soporte full-stack de BONO.
  - `src/components/BonoChatbot.tsx`: Asistente flotante con IA y recordatorios de tareas.
  - `src/components/ExecutiveReportsView.tsx`: Añadir gráfico comparativo de barras por colaborador y detección de cuellos de botella.
  - `src/components/InvictLogo.tsx`: Integrar imágenes reales (`/assets/invict-logo-real.jpeg`, `/assets/invict-emblem-real.jpeg`).
  - `src/utils/cloudSyncService.ts`: Remover claves universales y robustecer tokens de recuperación.
  - `src/components/LoginScreen.tsx`: Conector a Gmail/Outlook y eliminación de botones de clave universal.
  - `src/components/Header.tsx` y `src/components/Sidebar.tsx`: Ocultar cambio de puesto a usuarios no-gerenciales y añadir botón de instalación PWA.
  - `public/manifest.json`, `public/sw.js`, `src/hooks/usePWAInstall.ts`, `src/components/PWAInstallGuideModal.tsx`.
